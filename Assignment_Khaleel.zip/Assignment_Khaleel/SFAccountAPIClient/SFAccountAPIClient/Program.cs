﻿using System;
using RestSharp;
using System.Configuration;
using System.Collections.Specialized;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Data;
using System.Data.SqlClient;

namespace SFAccountAPIClient
{
    class Program
    {
        static void Main(string[] args)
        {
            string accessKey = string.Empty;
            string instanceURL = string.Empty;
            string tokenType = string.Empty;
            try
            {
                //Post request to get back the access key which will be used in GET request authorizarion along with instance url 
                RestRequest request = new RestRequest(Method.POST);
                if (ConfigurationManager.GetSection("RequestParameters") is NameValueCollection requestParameter)
                {
                    var client = new RestClient(requestParameter["BaseAddress"]);
                    request.AddParameter("username", requestParameter["username"]);
                    request.AddParameter("password", requestParameter["password"]);
                    request.AddParameter("grant_type", requestParameter["grant_type"]);
                    request.AddParameter("client_id", requestParameter["client_id"]);
                    request.AddParameter("client_secret", requestParameter["client_secret"]);
                    Console.WriteLine("API POST request is issued to receive the access key.");
                    IRestResponse response = client.Execute(request);
                    if (response.IsSuccessful)
                    {
                        var responseObject = JObject.Parse(response.Content);
                        accessKey = responseObject.GetValue("access_token").ToString();
                        instanceURL = responseObject.GetValue("instance_url").ToString();
                        tokenType = responseObject.GetValue("token_type").ToString();
                        DataTable accountDetails = GetAccountObjectDetails(accessKey, instanceURL, tokenType);
                        if (accountDetails.Rows.Count > 0)
                        {
                            SaveAccountDetails(accountDetails);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Post Request Status Code = " + response.StatusCode + " and StatusDescription = " + response.StatusDescription.ToString());
                        Console.ReadLine();
                    }
                }
                else
                {
                    Console.WriteLine("There is no sufficient request parameter information to make API call.");
                    Console.ReadLine();
                }
                
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.ReadLine();
            }

        }
        /// <summary>
        /// GET Request to salesforce API to get the account object details using accessKey
        /// </summary>
        /// <param name="accessKey"></param>
        /// <param name="instanceURL"></param>
        /// <param name="tokenType"></param>
        /// <returns></returns>
        public static DataTable GetAccountObjectDetails(string accessKey, string instanceURL, string tokenType)
        {
            DataTable AccountDetails = new DataTable();
            try
            {
                string baseURL = string.Empty;
                if (!string.IsNullOrEmpty(accessKey) && !string.IsNullOrEmpty(instanceURL) && !string.IsNullOrEmpty(tokenType))
                {
                    baseURL = instanceURL + "/services/data/v52.0/sobjects/Account/0015g00000QwKsVAAV";
                    var client = new RestClient(baseURL);
                    var request = new RestRequest(Method.GET);
                    request.AddHeader("accept", "application/json");
                    request.AddHeader("Authorization", tokenType + " " + accessKey);
                    Console.WriteLine("API GET request is issued to receive the account object details.");
                    IRestResponse response = client.Execute(request);
                    if (response.IsSuccessful)
                    {
                        var responseObject = JObject.Parse(response.Content);
                        responseObject.Property("attributes").Remove();
                        responseObject.Property("BillingAddress").Remove();
                        responseObject.Property("ShippingAddress").Remove();
                        Console.WriteLine("GET Request Response is " + responseObject);
                        JArray array = new JArray();
                        array.Add(responseObject);
                        AccountDetails = (DataTable)JsonConvert.DeserializeObject(array.ToString(), (typeof(DataTable)));
                    }
                    else
                    {
                        Console.WriteLine("Get Request Status Code = " + response.StatusCode + " and StatusDescription = " + response.StatusDescription.ToString());
                        Console.ReadLine();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.ReadLine();
            }
            return AccountDetails;
        }
        /// <summary>
        /// Method to save the account object details into SQL server database
        /// </summary>
        /// <param name="Accounts"></param>
        public static void SaveAccountDetails(DataTable Accounts)
        {
            try
            {
                string cs = ConfigurationManager.ConnectionStrings["DBConnection"].ConnectionString;
                using (SqlConnection databaseConnection = new SqlConnection(cs))
                {
                    SqlCommand cmd = new SqlCommand("InsertAccountDetails", databaseConnection)
                    {
                        CommandType = CommandType.StoredProcedure
                    };
                    SqlParameter param = new SqlParameter()
                    {
                        ParameterName = "@AccountTableType",
                        Value = Accounts
                    };
                    cmd.Parameters.Add(param);
                    databaseConnection.Open();
                    cmd.ExecuteNonQuery();
                    databaseConnection.Close();
                    Console.WriteLine("Account object details saved successfully.");
                    Console.ReadLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message.ToString());
                Console.ReadLine();
            }
        }

    }
}



