USE [SFAccountSystem]
GO

/****** Object:  Table [dbo].[AccountDetails]    Script Date: 9/13/2021 12:10:07 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AccountDetails](
	[Id] [nvarchar](20) NULL,
	[IsDeleted] [nvarchar](5) NULL,
	[MasterRecordId] [nvarchar](20) NULL,
	[Name] [nvarchar](20) NULL,
	[Type] [nvarchar](20) NULL,
	[RecordTypeId] [nvarchar](20) NULL,
	[ParentId] [nvarchar](20) NULL,
	[BillingStreet] [nvarchar](max) NULL,
	[BillingCity] [nvarchar](20) NULL,
	[BillingState] [nvarchar](20) NULL,
	[BillingPostalCode] [nvarchar](20) NULL,
	[BillingCountry] [nvarchar](20) NULL,
	[BillingLatitude] [nvarchar](20) NULL,
	[BillingLongitude] [nvarchar](20) NULL,
	[BillingGeocodeAccuracy] [nvarchar](20) NULL,
	[ShippingStreet] [nvarchar](max) NULL,
	[ShippingCity] [nvarchar](20) NULL,
	[ShippingState] [nvarchar](20) NULL,
	[ShippingPostalCode] [nvarchar](20) NULL,
	[ShippingCountry] [nvarchar](20) NULL,
	[ShippingLatitude] [nvarchar](20) NULL,
	[ShippingLongitude] [nvarchar](20) NULL,
	[ShippingGeocodeAccuracy] [nvarchar](20) NULL,
	[Phone] [nvarchar](20) NULL,
	[Fax] [nvarchar](20) NULL,
	[AccountNumber] [nvarchar](20) NULL,
	[Website] [nvarchar](20) NULL,
	[PhotoUrl] [nvarchar](max) NULL,
	[Sic] [nvarchar](20) NULL,
	[Industry] [nvarchar](20) NULL,
	[AnnualRevenue] [nvarchar](20) NULL,
	[NumberOfEmployees] [nvarchar](20) NULL,
	[Ownership] [nvarchar](20) NULL,
	[TickerSymbol] [nvarchar](20) NULL,
	[Description] [nvarchar](20) NULL,
	[Rating] [nvarchar](20) NULL,
	[Site] [nvarchar](20) NULL,
	[OwnerId] [nvarchar](20) NULL,
	[CreatedDate] [datetimeoffset](7) NULL,
	[CreatedById] [nvarchar](20) NULL,
	[LastModifiedDate] [datetimeoffset](7) NULL,
	[LastModifiedById] [nvarchar](20) NULL,
	[SystemModstamp] [nvarchar](20) NULL,
	[LastActivityDate] [datetimeoffset](7) NULL,
	[LastViewedDate] [datetimeoffset](7) NULL,
	[LastReferencedDate] [datetimeoffset](7) NULL,
	[Jigsaw] [nvarchar](20) NULL,
	[JigsawCompanyId] [nvarchar](20) NULL,
	[CleanStatus] [nvarchar](20) NULL,
	[AccountSource] [nvarchar](20) NULL,
	[DunsNumber] [nvarchar](20) NULL,
	[Tradestyle] [nvarchar](20) NULL,
	[NaicsCode] [nvarchar](20) NULL,
	[NaicsDesc] [nvarchar](20) NULL,
	[YearStarted] [datetime] NULL,
	[SicDesc] [nvarchar](20) NULL,
	[DandbCompanyId] [nvarchar](20) NULL,
	[OperatingHoursId] [nvarchar](20) NULL,
	[CustomerPriority__c] [nvarchar](20) NULL,
	[SLA__c] [nvarchar](20) NULL,
	[Active__c] [nvarchar](20) NULL,
	[NumberofLocations__c] [nvarchar](20) NULL,
	[UpsellOpportunity__c] [nvarchar](20) NULL,
	[SLASerialNumber__c] [nvarchar](20) NULL,
	[SLAExpirationDate__c] [datetime] NULL
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO


