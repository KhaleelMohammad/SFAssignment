USE [SFAccountSystem]
GO

/****** Object:  StoredProcedure [dbo].[InsertAccountDetails]    Script Date: 9/13/2021 12:30:05 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
 This procedure takes table as an input paramater and saves the 
 Account Object details into database
*/
CREATE PROC [dbo].[InsertAccountDetails]
@AccountTableType AccountTableType READONLY
AS
BEGIN
	INSERT INTO AccountDetails
	SELECT * FROM  @AccountTableType
END
GO


